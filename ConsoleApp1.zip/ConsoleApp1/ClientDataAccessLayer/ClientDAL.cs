﻿using ClientEntities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClientExceptions;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace ClientDataAccessLayer
{
	public class ClientDAL
	{
		public static List<Client> visitorList = new List<Client>();

		public bool AddVisitorDAL(Client newVisitor)
		{
			bool visitorAdded = false;
			try
			{
				visitorList.Add(newVisitor);



				visitorAdded = true;
			}
			catch (SystemException ex)
			{
				throw new ClientException(ex.Message);
			}
			return visitorAdded;
		}

		public Client SearchVisitorDAL(string searchVisitor)
		{
			Client visitorSearch = null;
			try
			{
				visitorSearch = visitorList.Find(visitor => visitor.VoterId == searchVisitor);
			}
			catch (SystemException ex)
			{
				throw new ClientException(ex.Message);
			}
			return visitorSearch;
		}



		public List<Client> GetAllVisitorDAL()
		{

			return visitorList;

		}

		public static void SerializeData(List<Client> v1)
		{
			FileStream fileStream = new FileStream("ser.dat", FileMode.Create);
			BinaryFormatter binaryFormatter = new BinaryFormatter();
			binaryFormatter.Serialize(fileStream, v1);
			fileStream.Close();
		}

		public static void DeserializeData()
		{
			FileStream fileStream = new FileStream("ser.dat", FileMode.Open);
			BinaryFormatter binaryFormatter = new BinaryFormatter();
			List<Client> e1 = (List<Client>)binaryFormatter.Deserialize(fileStream);
			fileStream.Close();

		}
	}
}
