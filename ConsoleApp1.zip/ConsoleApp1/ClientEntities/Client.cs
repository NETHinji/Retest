﻿using ClientExceptions;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ClientEntities
{
	[Serializable]
	public class Client
	{
		public string VoterId { get; set; }
		public string VoterName { get; set; }
		public eWard Ward { get; set; }
		public eCity City { get; set; }
		public string State { get; set; }
		public PartyToVote PartyToVoteFor { get; set; }
		public string ReasonToVote { get; set; }
		public enum PartyToVote
		{
			Congress,
			BJP,
			JD
		}
		public enum eCity
		{
			Bangalore,
			Mysore,
			Hubli
		}
		public enum eWard
		{
			North,
			South,
			East,
			West
		}
	}
}
