﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClientDataAccessLayer;
using ClientEntities;
using ClientExceptions;

namespace ClientBuisnessLogic
{
	public class ClientBLL
	{
		private static bool ValidateClient(Client visitor)
		{
			StringBuilder sb = new StringBuilder();
			bool validGuest = true;
			string x = visitor.VoterId.Substring(0, 2);
			string y = visitor.VoterId.Substring(2, 4);
			if (x.All(Char.IsLower)||!y.All(Char.IsNumber))
			{
				validGuest = false;
				sb.Append(Environment.NewLine + "Invalid Visitor Gate Pass ID");

			}
			if (visitor.VoterName == string.Empty)
			{
				validGuest = false;
				sb.Append(Environment.NewLine + "Visitor Name Required");

			}
			if((int)visitor.Ward>3)
			{
				validGuest = false;
				sb.Append(Environment.NewLine + "Invalid Ward");
			}
			if ((int)visitor.PartyToVoteFor > 2)
			{
				validGuest = false;
				sb.Append(Environment.NewLine + "Invalid Party");
			}
			if (visitor.ReasonToVote.Length>200)
			{
				validGuest = false;
				sb.Append(Environment.NewLine + "ReasonToVote should be less than 200");
			}

			if (validGuest == false)
				throw new ClientException(sb.ToString());
			return validGuest;
		}



		public static Client SearchClientBLL(string searchVisitorID)
		{
			Client searchVisitor = null;
			try
			{
				ClientDAL guestDAL = new ClientDAL();
				searchVisitor = guestDAL.SearchVisitorDAL(searchVisitorID);
			}
			catch (ClientException ex)
			{
				throw ex;
			}
			catch (Exception ex)
			{
				throw ex;
			}
			return searchVisitor;
		}


		public static bool AddClientBLL(Client newVisitor)
		{
			bool visitorAdded = false;
			try
			{
				if (ValidateClient(newVisitor))
				{
					ClientDAL visitorDAL = new ClientDAL();
					visitorAdded = visitorDAL.AddVisitorDAL(newVisitor);
				}
			}
			catch (ClientException)
			{
				throw;
			}
			catch (Exception ex)
			{
				throw ex;
			}

			return visitorAdded;
		}

		public static List<Client> GetAllVisitorBLL()
		{
			List<Client> visitorList = null;
			try
			{
				ClientDAL guestDAL = new ClientDAL();
				visitorList = guestDAL.GetAllVisitorDAL();
			}
			catch (ClientException ex)
			{
				throw ex;
			}
			catch (Exception ex)
			{
				throw ex;
			}
			return visitorList;
		}
	}
}
