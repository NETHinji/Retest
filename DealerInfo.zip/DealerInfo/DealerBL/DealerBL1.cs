﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dealer;
using DealerException;

namespace DealerBL
{
    public class DealerBL1
    {
        //public bool AddDealerBL(DealerEntity dealerEntity)
        //{

        //}
    }
}
