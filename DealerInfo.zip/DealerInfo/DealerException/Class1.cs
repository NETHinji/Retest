﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DealerException
{
    public class DealerException1:ApplicationException
    {
       public DealerException1() { }
        public DealerException1(string Message) : base(Message) { }
        public DealerException1(string Message,Exception ex) : base(Message, ex) { }
    }
}
