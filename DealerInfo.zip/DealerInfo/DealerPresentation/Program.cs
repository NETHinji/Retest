﻿using Dealer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DealerPresentation
{
    class Program
    {
        static void Main(string[] args)
        {
            int choice;
            while (true)
            {
                Console.WriteLine("1.Add");
                Console.WriteLine("2.Search");
                Console.WriteLine("3.Display");
                Console.WriteLine("4.Exit");
                Console.WriteLine("Enter your choice");
                choice = Convert.ToInt32(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddDealer();
                        break;
                    case 2:
                        SearchDealer();
                        break;
                    case 3:
                        Display();
                        break;
                    case 4:
                        Console.ReadLine();
                        break;
                    default:
                        Console.WriteLine("Wrong choice");
                        break;
                    
                }
            }

        }

        private static void AddDealer()
        {
            try
            {
                DealerEntity dealerEntity = null;
                Console.WriteLine("Enter dealer id");
                dealerEntity.DealerID = Console.ReadLine();
                Console.WriteLine("Enter dealer name");
                dealerEntity.DealerName = Console.ReadLine();
                Console.WriteLine("Enter dealer address");
                dealerEntity.DealerAddress = Console.ReadLine();
                Console.WriteLine("Enter dealer email id");
                dealerEntity.DealerEmailID = Console.ReadLine();
                Console.WriteLine("Enter dealer phoneno");
                dealerEntity.DealerPhoneNo = Console.ReadLine();
                Console.WriteLine("enter status");
                dealerEntity.DealerStatus = Console.ReadLine();
                Console.WriteLine("enter category");
                dealerEntity.DealerProductcategory = Console.ReadLine();
                DealerBL1 bL = new DealerBL1();
                bool added = bL.AddDealerBL(dealerEntity);
                if (added == true)
                {
                    Console.WriteLine("Dealer added");
                }

            }
            catch (SystemException ex)
            {

                Console.WriteLine(ex.Message);
            }
        }
        public static void SearchDealer()
        {
            List<DealerEntity> dealers = null;
            Console.WriteLine("Enter the category");
            string category = Console.ReadLine();
            DealerBL1 bl = new DealerBL1();
            dealers = b1.SearchBL(category);
            foreach(DealerEntity dealerEntity in dealers)
            {
                Console.WriteLine();
            }
        }
        public static void Display()
        {
            DealerBl1 bl = new DealerBl1();
            List<DealerEntity> dealers = null;
            foreach(DealerEntity dealer in dealers)
            {
                Console.WriteLine();
            }
        }
    }
}
