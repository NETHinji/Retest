﻿using Dealer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DealerException;

namespace DealerDAL
{
    public class DealerDAL1
    {
        static List<DealerEntity> dealerEntities = new List<DealerEntity>();
        public bool AddDealer(DealerEntity dealer)
        {
            bool added = false;
            try
            {
                dealerEntities.Add(dealer);
                added = true;
            }
            catch (SystemException ex)
            {

                throw;
            }
            catch(DealerException1 ex)
            {
                throw;
            }
            return added;
        }
        public List<DealerEntity> GetListDal()
        {
            return dealerEntities;
        }
        public List<DealerEntity> SearchDAL(string category)
        {
             List<DealerEntity> entity= null;
            try
            {
                foreach (DealerEntity d in dealerEntities)
                {
                    if (d.DealerProductcategory==category)
                    {
                        entity.Add(d);
                    }
                }
            }
            catch (SystemException ex)
            {

                throw;
            }
            catch(DealerException1 ex)
            {
                throw;
            }
            return entity;
        }
    }
}
