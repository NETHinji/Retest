﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolidPrincipleEg
{
    class Customer
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Gender { get; set; }
        public DateTime DateOfBirth { get; set; }
    }
    // This Program is Violating Single Responsibility Principle
    class CustomerBO 
    {
        static List<Customer> cList = null;
        public CustomerBO() {
            cList = new List<Customer>();
        }
        public bool AddCustomer(Customer custObj)
        {

            cList.Add(custObj);

            return true;
        }
    }
    class CustomerReport
    {
        public void ExportCustomerReport(string reportType)
        {
            if (reportType == "doc")
            {
                Console.WriteLine("store data in word file");

            }
           else if (reportType == "pfd")
            {
                Console.WriteLine("store data in pdf file");

            }
           else
            {
                Console.WriteLine("store data in excel file");

            }
        }
    
        static void Main(string[] args)
        {
            Customer c = new Customer();
            CustomerReport cReport = new CustomerReport();
            cReport.ExportCustomerReport("doc");
        }
    }
}
