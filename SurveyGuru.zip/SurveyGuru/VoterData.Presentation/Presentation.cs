﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VotingApplication.DataAccessLayer;
using VotingApplication.BusinessLayer;
using VotingApplication.EntityLayer;
using VotingApplication.ExceptionLayer;
using System.IO;

namespace VotingApplication.Presentation
{
    class program
    {

        List<Entities> visitorList = new List<Entities>();

        static void Main(string[] args)
        {



            int choice;
            do
            {
                if (File.Exists("ser.dat"))
                    DAL.DeserializeData();
                PrintMenu();
                Console.WriteLine("Enter your Choice:");
                choice = Convert.ToInt32(Console.ReadLine());

                switch (choice)
                {
                    case 1:

                        AddEntities();
                        break;
                    case 2:
                        ListAllEntities();
                        break;
                    case 3:
                        SearchEntitiesByID();
                        break;


                    case 4:

                        return;
                    default:
                        Console.WriteLine("Invalid Choice");
                        break;


                }

            } while (choice != -1);
        }

        private static void SearchEntitiesByID()
        {
            try
            {
                string searchVisitorID;
                Console.WriteLine("Enter Visitor Gate Pass ID to Search:");
                searchVisitorID = Console.ReadLine();
                Entities searchVisitor = BL.SearchClientBLL(searchVisitorID);
                if (searchVisitor != null)
                {
                    Console.WriteLine("\t\t\t******************************************************************************");
                    Console.WriteLine("VoterID\t\tName\t\tWard\t\tCity\t\tState\t\tPartytoVote\t\tReason");
                    Console.WriteLine("\t\t\t******************************************************************************");
                    Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}\t\t{6}", searchVisitor.VoterId, searchVisitor.VoterName,
                                        searchVisitor.Ward, searchVisitor.City, searchVisitor.State, searchVisitor.PartyToVoteFor, searchVisitor.ReasonToVote);

                    Console.WriteLine("\t\t\t******************************************************************************");
                }
                else
                {
                    Console.WriteLine("No Guest Details Available");
                }

            }
            catch (VoterListException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void AddEntities()
        {
            try
            {
                List<Entities> visitorList = new List<Entities>();
                Entities newVisitor = new Entities();

                Random rn = new Random();
                Console.WriteLine("Enter Visitor ID :");
                newVisitor.VoterId = Console.ReadLine();
                Console.WriteLine("Enter Visitor Name :");
                newVisitor.VoterName = Console.ReadLine();

                newVisitor.State = "Karnataka";
                Console.WriteLine("Enter the city\n 0.Bangalore \t 1.Mysore \t 2.Hubli");
                newVisitor.City = (Entities.eCity)(Convert.ToInt32(Console.ReadLine()));
                Console.WriteLine("Enter the ward\n 0.North \t 1.South \t 2.East \t 3.West");
                newVisitor.Ward = (Entities.eWard)(Convert.ToInt32(Console.ReadLine()));
                Console.WriteLine("Enter the Party to vote for \n 0.Congress \t 1.BJP \t 2.JD");
                newVisitor.PartyToVoteFor = (Entities.PartyToVote)(Convert.ToInt32(Console.ReadLine()));
                Console.WriteLine("Enter the reason");
                newVisitor.ReasonToVote = Console.ReadLine();

                bool guestAdded = BL.AddClientBLL(newVisitor);
                if (guestAdded)
                    Console.WriteLine("Voter Added");
                else
                    Console.WriteLine("Voter not Added");
                DAL.SerializeData(visitorList);
            }
            catch (VoterListException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void ListAllEntities()
        {
            try
            {

                List<Entities> visitorList = BL.GetAllVisitorBLL();
                if (visitorList != null)
                {
                    Console.WriteLine("\t\t\t******************************************************************************");
                    Console.WriteLine("VoterID\t\tName\t\tWard\t\tCity\t\tState\t\tPartytoVote\t\tReason");
                    Console.WriteLine("\t\t\t******************************************************************************");
                    foreach (Entities visitor in visitorList)
                    {
                        Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}\t\t{5}\t\t{6}", visitor.VoterId, visitor.VoterName,
                                        visitor.Ward, visitor.City, visitor.State, visitor.PartyToVoteFor, visitor.ReasonToVote);
                    }
                    Console.WriteLine("\t\t\t******************************************************************************");

                }
                else
                {
                    Console.WriteLine("No Guest Details Available");
                }
            }
            catch (VoterListException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }


        private static void PrintMenu()
        {
            Console.WriteLine("\n***********Guest PhoneBook Menu***********");
            Console.WriteLine("1. Add Guest");
            Console.WriteLine("2. List All Guests");
            Console.WriteLine("3. Search  by Gate Pass ID");
            Console.WriteLine("4. Exit");
            Console.WriteLine("******************************************\n");

        }
    }
}
