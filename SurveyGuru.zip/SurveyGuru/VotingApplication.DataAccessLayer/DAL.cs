﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using VotingApplication.EntityLayer;
using VotingApplication.ExceptionLayer;

namespace VotingApplication.DataAccessLayer
{
    public class DAL
    {
        public static List<Entities> visitorList = new List<Entities>();

        public bool AddVisitorDAL(Entities newVisitor)
        {
            bool visitorAdded = false;
            try
            {
                visitorList.Add(newVisitor);



                visitorAdded = true;
            }
            catch (SystemException ex)
            {
                throw new VoterListException(ex.Message);
            }
            return visitorAdded;
        }

        public Entities SearchVisitorDAL(string searchVisitor)
        {
            Entities visitorSearch = null;
            try
            {
                visitorSearch = visitorList.Find(visitor => visitor.VoterId == searchVisitor);
            }
            catch (SystemException ex)
            {
                throw new VoterListException(ex.Message);
            }
            return visitorSearch;
        }



        public List<Entities> GetAllVisitorDAL()
        {

            return visitorList;

        }

        public static void SerializeData(List<Entities> v1)
        {
            FileStream fileStream = new FileStream("ser.dat", FileMode.Create);
            BinaryFormatter binaryFormatter = new BinaryFormatter();
            binaryFormatter.Serialize(fileStream, v1);
            fileStream.Close();
        }

        public static void DeserializeData()
        {
            FileStream fileStream = new FileStream("ser.dat", FileMode.Open);
            BinaryFormatter binaryFormatter = new BinaryFormatter();
            List<Entities> e1 = (List<Entities>)binaryFormatter.Deserialize(fileStream);
            fileStream.Close();

        }
    }
}
