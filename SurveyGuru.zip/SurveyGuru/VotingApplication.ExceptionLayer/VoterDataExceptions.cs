﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace VotingApplication.ExceptionLayer
{
    [Serializable]
    public class VoterListException : Exception
    {
        public VoterListException()
        {
        }

        public VoterListException(string message) : base(message)
        {
        }

        public VoterListException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected VoterListException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}