﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using VotingApplication.DataAccessLayer;
using VotingApplication.EntityLayer;
using VotingApplication.ExceptionLayer;

namespace VotingApplication.BusinessLayer
{
        public class BL
    {
        private static bool ValidateClient(Entities visitor)
        {
            StringBuilder sb = new StringBuilder();
            bool validGuest = true;
            string x = visitor.VoterId.Substring(0, 2);
            string y = visitor.VoterId.Substring(2, 4);
            if (x.All(Char.IsLower) || !y.All(Char.IsNumber))
            {
                validGuest = false;
                sb.Append(Environment.NewLine + "Invalid Voter Gate Pass ID");

            }
            if (visitor.VoterName == string.Empty)
            {
                validGuest = false;
                sb.Append(Environment.NewLine + "Voter Name Required");

            }
            if ((int)visitor.Ward > 3)
            {
                validGuest = false;
                sb.Append(Environment.NewLine + "Invalid Ward");
            }
            if ((int)visitor.PartyToVoteFor > 2)
            {
                validGuest = false;
                sb.Append(Environment.NewLine + "Invalid Party");
            }
            if (visitor.ReasonToVote.Length > 200)
            {
                validGuest = false;
                sb.Append(Environment.NewLine + "ReasonToVote should be less than 200");
            }

            if (validGuest == false)
                throw new VoterListException(sb.ToString());
            return validGuest;
        }



        public static Entities SearchClientBLL(string searchVisitorID)
        {
            Entities searchVisitor = null;
            try
            {
                DAL guestDAL = new DAL();
                searchVisitor = guestDAL.SearchVisitorDAL(searchVisitorID);
            }
            catch (VoterListException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return searchVisitor;
        }


        public static bool AddClientBLL(Entities newVisitor)
        {
            bool visitorAdded = false;
            try
            {
                if (ValidateClient(newVisitor))
                {
                    DAL visitorDAL = new DAL();
                    visitorAdded = visitorDAL.AddVisitorDAL(newVisitor);
                }
            }
            catch (VoterListException)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return visitorAdded;
        }

        public static List<Entities> GetAllVisitorBLL()
        {
            List<Entities> visitorList = null;
            try
            {
                DAL guestDAL = new DAL();
                visitorList = guestDAL.GetAllVisitorDAL();
            }
            catch (VoterListException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return visitorList;
        }
    }
}
