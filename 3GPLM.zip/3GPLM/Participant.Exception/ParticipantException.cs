﻿using System;
using System.Runtime.Serialization;

namespace Participant.Exception
{
    [Serializable]
    public class ParticipantException : System.Exception
    {
        public ParticipantException()
        {
        }

        public ParticipantException(string message) : base(message)
        {
        }

        public ParticipantException(string message, System.Exception innerException) : base(message, innerException)
        {
        }

        protected ParticipantException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}