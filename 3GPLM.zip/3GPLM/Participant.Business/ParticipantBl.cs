﻿using Participant.DataAccess;
using System;
using System.Data;

namespace Participant.Business
{
    public class ParticipantBl
    {
        public DataTable Search(string voucherNo)
        {
            try
            {
                participantDl edl = new participantDl();
                return edl.Search(voucherNo);
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}