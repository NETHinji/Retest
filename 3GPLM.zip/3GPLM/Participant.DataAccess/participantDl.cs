﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Windows;

namespace Participant.DataAccess
{
    public class participantDl
    {
        SqlCommand cmd = new SqlCommand();
        static string Con = string.Empty;
        SqlConnection con1;

        static participantDl()
        {
            Con = ConfigurationManager.ConnectionStrings["Con"].ConnectionString;
        }
        public participantDl()
        {
            con1 = new SqlConnection(Con);
        }
        public DataTable Search(string voucherNo)
        {
            try
            {
                DataTable dt = new DataTable();
                cmd.CommandText = "PLM3G.Search";
                cmd.Connection = con1;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@voucherNo", voucherNo);
                con1.Open();

                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dt = new DataTable();
                    dt.Load(dr);
                }
                return dt;
            }
            catch (Exception)
            {

                throw;
            }


            


        }
    }
}